import Header from "./Header";
const Home = (props) => {
    
    return (
        <div>
            <Header register={props.register}/>
        </div>
    )
}
export default Home