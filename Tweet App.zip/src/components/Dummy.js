import { useLocation } from "react-router"

export default function Dummy() {

    let location = useLocation()
    return(
        <div>{location}</div>
    )
}


    // function handleLike(data) {
    //     console.log(data)
    //     setTweetIndex(data)
    //     fetch("http://localhost:8083/likeTweet/", {
    //         method: 'PUT',
    //         headers: {
    //             "Content-Type": "application/json"            },
    //         body: tweetindex
    //     }).then((response) => {
    //         const json = response.json()
    //         // console.log(response.status)
    //         if (response.status === 200) {
    //             setValue('Liked')
    //             setDisable(true)
    //             alert("Liked a tweet with " + data)
    //             navigate('/success', { state: { userId: location.state.userId, username: location.state.username } })
    //             setDisable(false)
    //         }
    //         else {
    //             alert('could not like your tweet, please try again!')
    //         }
    //     })
    // }